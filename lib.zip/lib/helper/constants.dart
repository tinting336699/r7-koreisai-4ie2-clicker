const String collectionName = "clicker-unt1";
const String appTitle = "クリッカーゲーム";